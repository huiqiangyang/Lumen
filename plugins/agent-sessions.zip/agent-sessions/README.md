# Agent Session Titles — Lumen 示例插件

本插件把 4 个外部 agent（`pi`、`claude-code`、`codex`、`opencode`）的**私有 session 文件知识**
全部收在一处：文件在哪、文件名长什么样、文件里哪个字段是标题 / 项目目录 / 首问 / 时间、
以及用哪条命令恢复。Lumen 核心对这些格式一无所知（契约 R1）：`internal/agents`、`sdk`、
`cmd/lumen` 里不出现任何一家的名字或私有字段名；上游格式变了，只改本目录即可。

## 两种贡献点

| 贡献点 | 干什么 | 什么时候跑 | 谁解析 |
|---|---|---|---|
| `contributes.agentTitleProviders`（4 条，**保留**） | **给活着的终端取名**：终端里的 agent 没写 OSC 标题时，宿主盯住它正在写的 session 文件，把名字补到 tab 上 | 会话运行中，文件变化时 | 宿主找文件并读全文 → 调本插件的 `agentTitle({ provider, path, dir, text })` → `{ title }`（JS） |
| `contributes.agents`（4 条，**新增**） | **供侧栏「可恢复」组枚举与恢复**：列出本机这些 agent 的历史会话（标题、首问、目录、时间），选中后用 `resume` 模板经 argv 开新 PTY | 侧栏「全部」段的后台扫描 | 宿主按 `sessions` 描述符**纯 Go 声明式解析，不启动 JS**（契约 R2）；函数式 `agentSessions` 只是备用路径 |

两条贡献点故意使用**同一组 `id` / `aliases`**：`agents[].id` 就是 `agents.Session.Harness`，
恢复出来的 tab 会把它写进 `agentApp`，于是 live 的标题读取器（按命令行、OSC 0/2 窗口标题、
OSC 7501 的 `app=` 查名字）仍能命中同一张表。宿主登记插件 agent 时会查这张表的重名（契约 §9），
同插件、同名字、同别名的两条贡献描述的是**同一个 agent**，不是两个。

> **集成注意**：宿主登记 `agents` 时的重名检查必须把「同一插件、完全相同的 id/aliases」
> 当作同一个 agent 放行；若把标题读取器已占用的名字一律判为 `taken`，本插件 4 条 `agents`
> 会全被拒绝、侧栏「可恢复」组为空（live 标题不受影响）。这是宿主侧判定，契约 §9/§11
> 要求两张表共用同一组名字，所以插件侧不改数据。

`app` 字段与 OSC 7501 的 `app=` 对齐（这里取 `pi` / `claude` / `codex` / `opencode`，
本机上游若报别的名字，改 manifest 即可）；`icon` 是 24×24 viewBox 的 SVG path 片段
（写法同 `cmd/lumen/icons.go` 的 Lucide 图标），`dark` / `light` 是两种主题下的 hex 色调。

## 声明式 `sessions` 字段路径规则

`sessions` 的每个字段都是**一条**字段路径，不是一段代码，也不是一个正则：

- 路径由点号分隔，允许数组下标，例如 `payload.id`、`time.updated`、`messages.0.text`；
  每一段要么是对象的键，要么是数组的下标。取到的值必须是 JSON 的字符串或数字（时间可以是
  RFC 3339 文本，或 epoch 秒 / 毫秒数）；`prompt` 还允许是 `[{type:"text",text:"…"}]`
  这样的文本片段数组。
- `folders` 是**家目录下**的 glob，`match` 是**文件基名**的正则；两者与 4 条
  `agentTitleProviders` 完全一致（见下表），只是这次由 `internal/agents` 的扫描器展开。
- `format` 为 `jsonl`（逐行一个 JSON 对象）或 `json`（整个文件一个对象；`opencode` 用这个）。
  半行 / 坏行跳过——agent 写文件写到一半是常态。
- 一个 `jsonl` 文件里每条记录都可能带这些字段，宿主按下面的规则合成**一个** session：

  | 字段 | 取法 |
  |---|---|
  | `id` / `dir` / `updated` / `prompt` | **第一个非空** |
  | `title` | **最后一个非空**（标题会被改名，最后一次才算数） |

  空的 `id` / `updated` 由宿主按自己的默认处理（如文件名 / 文件 mtime，具体以宿主实现为准）；
  `title` 为空时侧栏按
  `Title > Prompt > ID` 显示；`dir` 为空时该会话不会算作「当前项目」。
- 声明式只认字段路径，**不认记录类型、不认条件**。原 JS 解析里的
  「只取 `role=user` 的消息」「过滤注入的 `<environment_context…>` / `/` 命令」
  「过滤 `New session - <时间戳>` 默认标题」「按文件夹 slug 判断是不是本项目」
  都无法表达；宿主改为按解析出来的 `Dir` 做项目过滤（`Session.In`）。
- 契约 §1 的 `ReadText` 只读头尾各 256 KiB 并丢掉接缝处的半行，一次扫描不会把整份历史读进内存；
  字段路径取值也只在这段文本里进行。

四条描述符（完整值见 `plugin.json`）：

| `id` | `format` | `folders` | `match` | `id` | `title` | `dir` | `updated` | `prompt` |
|---|---|---|---|---|---|---|---|---|
| `pi` | `jsonl` | `.pi/agent/sessions/*` | `\.jsonl$` | `id` | `name` | `cwd` | `timestamp` | `message.content` |
| `claude-code` | `jsonl` | `.claude/projects/*` | `\.jsonl$` | `sessionId` | `customTitle` | `cwd` | `timestamp` | `message.content` |
| `codex` | `jsonl` | `.codex/sessions/*/*/*` | `^rollout-.*\.jsonl$` | `payload.id` | `payload.message` | `payload.cwd` | `timestamp` | `payload.content` |
| `opencode` | `json` | `.local/share/opencode/storage/session/*` | `^ses_.*\.json$` | `id` | `title` | `directory` | `time.updated` | `title` |

其中 `pi.name` 来自 `session_info` 记录、`pi.message.content` 来自 `message` 记录；
`claude-code.customTitle` / `aiTitle` 来自 `custom-title` / `ai-title` 记录；
`codex.payload.*` 来自 `session_meta` / `event_msg` / `response_item` 记录；
`opencode` 的 `title` / `directory` / `time` 是单个会话 JSON 的顶层字段。

## `resume` 模板变量

`resume` 是命令模板，宿主展开后用 `QuoteArg` 逐项引用参数，再经
`startSessionWith(s.Dir, cmd, "", "")` 开新 PTY（**绝不** `term.Send(cmd+"\r")`，契约 R5）。
可用变量：`{id}`（会话 id）、`{folder}`（会话目录）、`{title}`、`{root}`（配置目录）。

| `id` | `resume` |
|---|---|
| `pi` | `pi --session {id}` |
| `claude-code` | `claude --resume {id}` |
| `codex` | `codex resume {id}` |
| `opencode` | `opencode run --session {id}` |

宿主已经把新 PTY 的 cwd 设成 `s.Dir`，所以四条模板都只用 `{id}`；需要显式切目录时改成
`"cd {folder} && codex resume {id}"` 这类形式即可。`claude --resume` 与 `codex resume` 是各家
稳定的恢复入口；**`pi --session` 与 `opencode run --session` 按上游版本可能有别的写法
（如 `pi --resume` / `opencode --continue`）**，这里取最保守、只带 id 的形式，模板是普通
manifest 数据，按本机版本直接改 `plugin.json` 即可，无需改任何 Go 代码。

## 函数式备用路径：`agentSessions`

`index.js` 仍导出 `agentTitle`（live watcher 用，连同 `parsePi` / `parseClaude` /
`parseCodex` / `parseOpencode` 四个解析器原样保留），另外导出 `agentSessions`：

```js
agentSessions({ id: "codex", path, text, dir })
// → { id, title, dir, updated, prompt }
agentSessions({ id: "codex", files: [{ path, text, dir }, ...] })
// → [ { id, title, dir, updated, prompt }, ... ]
```

它复用 `cleanTitle` / `bound` / `textOf` / `injectedPrompt` 和四个标题解析器：先用与
`plugin.json` 相同的字段路径（`sessionPaths` 表，两处必须一致）取值，字段路径给不出标题时
回退到四家解析器（于是注入提示过滤、项目检查、默认标题过滤又回来了）。坏行跳过、全程
try/catch 不抛、空文本回答空 session；不读文件系统、不引入任何依赖。

声明式为主，所以 manifest 里的 4 条 `agents` **不写 `export`**：宿主看到 `sessions` 就走
纯 Go 路径，不会为了枚举历史而启动 JS。想切到函数式（或调试某个文件）时，把某条的
`"sessions": {…}` 换成 `"export": "agentSessions"`，并确保宿主把 `{id,path,text,dir}`
传进来；此时该函数不能自己枚举文件，宿主需要自己找到文件并逐个调用。

## 字段路径的取舍

一个字段只能写**一条**路径，而四个解析器原本各有多个来源，这里逐一说明选谁、丢了什么：

- **`claude-code.title = customTitle`**：原优先级是
  `custom-title.customTitle` > `ai-title.aiTitle` > 旧版 `title` > 首条用户消息。取最高优先级
  的 `customTitle`（人起的名字，最后一条改名生效，正好合宿主的「Title 取最后一个非空」）。
  代价：AI 生成的标题在声明式下丢了；但 `prompt = message.content` 会给出首条用户消息，
  侧栏 `Title > Prompt > ID` 仍有可读的名字。没有选泛化的 `title`，因为附件 / 工具结果也带
  `title`，而声明式无法按记录类型排除它们。
- **`codex.title = payload.message`、`prompt = payload.content`**：这两条正是原解析器的
  「首条 `event_msg` 用户消息」和「首条 `response_item` 用户消息」兜底。代价：宿主对
  `Title` 取**最后**一个非空，因此会显示最近一条用户消息而不是首问；首问仍在 `prompt` 里。
- **`pi.title = name`、`prompt = message.content`**：`name` 是 `session_info` 的最后一个
  名字，与 `parsePi` 完全一致；`message.content` 是首条消息（宿主取第一个非空）。代价：
  声明式无法只看 `role=user`，也无法过滤注入提示，所以个别文件里首条助手消息可能顶替首问。
- **`opencode.prompt = title`**：opencode 的会话 JSON **不含首问**（消息另存），
  `title` 是文件里唯一的人可读文本，指向它保证该字段不空；`Label` 仍优先用 `Title`，
  重复文本只多进一次搜索索引。若嫌重复，把此项改成 `""` 即可。
- **`opencode.title = title`**：原解析器会滤掉 `New session - <时间戳>` / `Child session - …`
  默认标题、滤掉 `parentID` 子会话；声明式做不到，于是个别默认标题 / 子会话也会列出来。
- **`dir` 一律取文件里的目录字段**（`cwd` / `payload.cwd` / `directory`）。原 live 解析器
  对 `pi` 与 `claude-code` 是按**文件夹名**（slug）判断「是不是本项目」，那是一种路径运算，
  不是字段路径；声明式改用文件里的 `cwd`，宿主再用 `Session.In` 做项目过滤。
  `codex` / `opencode` 原本就记录目录，无变化。
- **`id` / `updated` 是同记录上的伴随字段**：`sessionId`、`payload.id`、`id` 都是恢复命令
  真正需要的 id；`timestamp` / `time.updated` 是各格式本来就写的时间。宿主对 `updated`
  取第一个非空，因此 `jsonl` 的时间通常是**会话开始**时刻而不是最后写入时刻。
  文件名兜底（如 `rollout-<日期>-<uuid>.jsonl`）与 id 未必相同，故 `id` 路径尽量指向文件内
  真正的会话 id。
- **Codex 的 `session_index.jsonl` 线程名查表依旧没有移植**：宿主只展开 `folders` 命中的
  session 文件，声明式和函数式都拿不到索引文件，理由与 live 标题路径相同。
- **Claude Code 旧版 `title` 字段**同样无法在声明式里限定「类型名含 title 的记录」。

函数式 `agentSessions` 因为回退到四个解析器，上面大部分丢失的信息（注入提示过滤、项目
检查、AI 标题、默认标题过滤）都能拿回来——这也是把它作为调试 / 备用路径的原因。

## 如何加第 5 个 agent

这正是插件化的意义：**只改本目录三个文件，核心零改动**（侧栏、扫描器、resume 全是从
manifest 数据驱动的）。

1. `plugin.json`：`contributes.agents` 追加一条，按 §2 的 `AgentDescriptor` 写全
   `id/name/aliases/app/icon/dark/light/resume/sessions`。若它也想在终端里取名，再往
   `agentTitleProviders` 追加一条（同样的 `id` / `aliases`、自己的 `folders` / `match`，
   `export` 保持 `agentTitle`）。
2. `index.js`：给 `agentTitle` 的 `switch` 加一个 `case` 和对应的 `parseXxx`（风格照现有四个：
   `lines()` / `textOf()` / `injectedPrompt()` / `bound()`），并在 `sessionPaths` 里加同样的
   五条字段路径；`agentSessions` 的 `parsedTitle` 也加一个 `case`。
3. `README.md`：补一行路径表与取舍说明。

例如（虚构的 `my-agent`，字段路径用到了数组下标，`{folder}` 也用上了）：

```json
{
  "id": "my-agent",
  "name": "My Agent",
  "aliases": ["ma"],
  "app": "my-agent",
  "icon": "<path d=\"M5 12h14\"/><path d=\"m12 5 7 7-7 7\"/>",
  "dark": "#8ab4f8",
  "light": "#1a73e8",
  "resume": "cd {folder} && my-agent resume {id}",
  "sessions": {
    "folders": [".my-agent/sessions/*"],
    "match": "^ses-.*\\.jsonl$",
    "format": "jsonl",
    "id": "meta.id",
    "title": "meta.title",
    "dir": "meta.cwd",
    "updated": "meta.updated",
    "prompt": "messages.0.text"
  }
}
```

注意 `id` / `aliases` 属于 agent 自己的全局命名空间（见下节），别和已有条目重名；`match`
要能滤掉同目录里的索引 / 临时文件；`format` 只能是 `json` 或 `jsonl`。

## 分工、安装与命名空间（原有约定）

- **live 标题**：宿主按 `agentTitleProviders` 的 `folders` glob 在家目录下展开目录，用 `match`
  正则匹配文件基名，读入变化文件的全文后调用 `agentTitle`。插件只解析文本，拿不到 `*app`、
  不能读文件系统，唯一接触到的路径就是参数里的 `path` / `dir`；所有解析都包在 try/catch 里，
  异常只会得到 `{ title: "" }`，空标题不会清掉宿主已有的名字。
- **未安装本插件时**：核心仍按终端标准协议显示标题（OSC 7501 的 `title=` / `app=`，然后
  OSC 0/2 窗口标题，最后退回 agent 名字）；核心内置的 reader 注册表启动时为空，只是没有
  「去读 agent 的 session 文件兜底」和侧栏的「可恢复」历史这两条路径。
- **安装**：应用不预装插件。目录方式（开发）把本目录复制到数据目录
  `plugins/agent-sessions/`（目录名与 manifest 的 `id` 一致）：

  ```bash
  # Linux
  cp -r examples/agent-sessions-plugin ~/.config/Lumen/plugins/agent-sessions
  # macOS
  cp -r examples/agent-sessions-plugin ~/Library/Application\ Support/Lumen/plugins/agent-sessions
  ```

  Zip 方式：`cd examples && zip -r agent-sessions-plugin.zip agent-sessions-plugin`，然后
  设置 → 插件 → `+` → *从 Zip 安装…*。装好后刷新插件页（或重启 Lumen）。
- **为什么 `id` 是裸的 agent 名**：查找键来自命令行、OSC 0/2 窗口标题和 OSC 7501 的
  `app=`，是 agent 们定义的全局命名空间，不是插件能改的；宿主先查别名再查 ID，加了
  `插件id.` 前缀就永远查不到。`registerAgentTitle` 会拒绝任何与已有 reader 的 ID 或别名
  重名的注册。

四个 provider 的 glob / 正则与各 agent 的环境变量覆盖（`PI_CODING_AGENT_DIR`、
`CLAUDE_CONFIG_DIR`、`CODEX_HOME`、`XDG_DATA_HOME`）沿用原约定：glob 固定相对家目录展开，
需要挪树的人建符号链接即可。

## 上游格式变化时

只需更新本目录的 `index.js`（函数解析）与 `plugin.json`（glob、正则、字段路径、resume），
重装即可，不用改 Lumen 本体。JSONL 逐行解析、注入提示过滤（`<environment_context…`、
`AGENTS.md`、`/` 命令）、80 字符截断、`^(New|Child) session - \d{4}-…` 默认标题过滤，
都还在 `index.js` 里。plugin.json 的 4 条 `agentTitleProviders` 原样保留，live watcher 的
行为不因新增 `agents` 而变化。

运行环境是普通插件 VM（256 MiB、30s 调用超时）；解析一次 session 文件远在超时之内，
且声明式路径根本不启动它。
