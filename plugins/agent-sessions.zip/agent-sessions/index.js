// Agent Session Titles: parses the private session files of four external
// coding agents — pi, Claude Code, Codex and opencode — into the names
// their tabs show. This is the plugin half of a split the host keeps:
//
//   - The host finds the files. It expands the folder globs of each
//     agentTitleProviders entry under the user's home directory, matches
//     a file's base name against the entry's regexp, reads a changed file
//     whole and calls the export below.
//   - The plugin reads a name out of the text. It never sees *app, never
//     touches the file system, and hears no path but the two the call
//     already names.
//
// Protocol: agentTitle({ provider, path, dir, text }) answers
// { title: "<name>" }, "" for "no name in this file". A plugin that threw
// would be a plugin the host logs about, so nothing here escapes: every
// parse is inside a try, and the worst case is an empty title, which the
// host treats as "no name yet" and keeps the one it had.
//
// `dir` is the session's working directory. pi and Claude Code keep one
// folder per project, so the folder a file sits in says which project it
// belongs to; Codex and opencode record the directory in the file. A file
// of another project is not this session's file, whatever its name.

// ---- the small tools the readers share ----

// stripEscapes drops CSI, OSC and two-character escapes an agent may have
// written inside a title, as the host's own cleaner does for the titles
// that arrive over the terminal's protocols.
function stripEscapes(s) {
  return String(s).replace(
    /\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07\x1b]*(?:\x07|\x1b\\)|[@-Z\\-_])/g,
    ""
  );
}

// cleanTitle makes a title safe to show outside the terminal: escapes,
// control characters and runs of whitespace are gone.
function cleanTitle(s) {
  if (s === undefined || s === null) return "";
  return stripEscapes(String(s))
    .replace(/[\u0000-\u001f\u007f\u0080-\u009f]/g, " ")
    .split(/\s+/)
    .filter((w) => w !== "")
    .join(" ");
}

// bound keeps a name one line long: an agent's first prompt is often a
// paragraph, and an AI title is short already.
function bound(s) {
  s = cleanTitle(s);
  const r = Array.from(s);
  return r.length > 80 ? r.slice(0, 80).join("") + "…" : s;
}

// or is Go's cmp.Or: the first argument that is not "".
function or(...vals) {
  for (const v of vals) if (v !== "") return v;
  return "";
}

// textOf is the text of a message's content, a string or a list of text
// parts, as agents keep either.
function textOf(content) {
  if (content === undefined || content === null) return "";
  if (typeof content === "string") return cleanTitle(content);
  if (!Array.isArray(content)) return "";
  const out = [];
  for (const p of content) {
    if (!p || typeof p !== "object") continue;
    if ((p.type === "text" || p.type === "input_text") && String(p.text || "").trim() !== "") {
      out.push(cleanTitle(p.text));
    }
  }
  return cleanTitle(out.join(" "));
}

// injectedPrompt is a prompt the agent wrote for itself, or a command,
// neither of which names the session. Only a prompt that *starts* with an
// injected block is one; a person may well ask about AGENTS.md by name.
function injectedPrompt(s) {
  s = String(s || "").trim();
  if (s === "" || s.startsWith("/")) return true;
  return ["<environment_context", "<user_instructions", "<local-command-",
    "<command-name>", "AGENTS.md", "CLAUDE.md"].some((p) => s.startsWith(p));
}

// lines walks a JSONL file, letting each line decide what it contributes
// to the name. Like the host's own reader, it stops at the first line it
// cannot decode: a live file may end in a partial line.
function lines(text, fn) {
  for (const raw of String(text).split("\n")) {
    const line = raw.trim();
    if (line === "") continue;
    let o;
    try {
      o = JSON.parse(line);
    } catch (e) {
      break;
    }
    if (o && typeof o === "object") fn(o);
  }
}

// cleanPath is filepath.Clean close enough to compare two directories:
// separators are one kind, duplicates collapse, trailing ones are gone.
function cleanPath(p) {
  p = String(p || "").replace(/[\\/]+/g, "/").replace(/\/+$/, "");
  return p === "" ? "/" : p;
}

// slug is the folder name Claude Code gives a working directory:
// separators and other punctuation become dashes.
function slug(dir) {
  return cleanPath(dir).replace(/[^a-zA-Z0-9]/g, "-");
}

// piFolder is the folder pi names after a working directory: it strips
// the leading separator, then replaces separators and colons with dashes,
// so /work/lumen becomes --work-lumen-- and the session folder is that
// wrapped in dashes again.
function piFolder(dir) {
  return "--" + cleanPath(dir).replace(/^[\\/]+/, "").replace(/[\\/:]/g, "-") + "--";
}

// ownProject says whether path sits in the folder the agent named after
// dir, by that agent's scheme. An unknown dir filters nothing: without it
// there is nothing to compare against.
function ownProject(path, dir, folderOf) {
  if (!dir) return true;
  const at = String(path || "").replace(/[\\/]+/g, "/").split("/");
  at.pop(); // the file's name
  return at.pop() === folderOf(dir);
}

// ---- pi ----

// pi keeps one JSONL folder per project under
// ~/.pi/agent/sessions/--<project>--. The folder glob lists every
// project's folder, so a file of another project is not this session's;
// the last session_info name wins, and before one is set the first user
// prompt that is not injected does.
function parsePi(path, dir, text) {
  if (!ownProject(path, dir, piFolder)) return "";
  let name = "", first = "";
  lines(text, (o) => {
    if (o.type === "session_info") {
      const n = cleanTitle(o.name);
      if (n !== "") name = n; // the last name set wins
    } else if (o.type === "message" && first === "") {
      const msg = o.message && typeof o.message === "object" ? o.message : {};
      if (msg.role !== "user") return;
      const t = textOf(msg.content);
      if (!injectedPrompt(t)) first = t;
    }
  });
  return bound(or(name, first));
}

// ---- Claude Code ----

// Claude Code keeps one JSONL folder per project under
// ~/.claude/projects/<slug>. A name given or generated by the agent wins
// over the first prompt that is not injected; older builds wrote a plain
// title on a record whose type is itself a title, but an attachment or a
// tool result may carry a `title` of its own that is not the session's.
function parseClaude(path, dir, text) {
  let custom = "", ai = "", legacy = "", first = "";
  lines(text, (o) => {
    if (o.type === "custom-title") {
      custom = or(cleanTitle(o.customTitle), cleanTitle(o.title));
    } else if (o.type === "ai-title") {
      ai = or(cleanTitle(o.aiTitle), cleanTitle(o.title));
    } else if (o.type === "user") {
      if (first !== "" || o.isMeta === true || o.isCompactSummary === true) return;
      const msg = o.message && typeof o.message === "object" ? o.message : {};
      const t = textOf(msg.content);
      if (!injectedPrompt(t)) first = t;
    } else {
      const typ = String(o.type || "");
      if (typ.includes("title")) {
        const t = cleanTitle(o.title);
        if (t !== "") legacy = t;
      }
    }
  });
  if (!ownProject(path, dir, slug)) return "";
  return bound(or(custom, ai, legacy, first));
}

// ---- Codex ----

// Codex shards its rollouts by day under ~/.codex/sessions/<y>/<m>/<d>/.
// A rollout records the project it ran in; one of another project does
// not name this session. The first user message, then the first user
// item, is the name; prompts the agent injected are not.
function parseCodex(path, dir, text) {
  let cwd = "", first = "", fallback = "";
  lines(text, (o) => {
    const p = o.payload && typeof o.payload === "object" ? o.payload : {};
    if (o.type === "session_meta") {
      cwd = String(p.cwd || "");
    } else if (o.type === "event_msg") {
      if (first !== "" || p.type !== "user_message") return;
      const t = cleanTitle(p.message);
      if (!injectedPrompt(t)) first = t;
    } else if (o.type === "response_item") {
      if (fallback !== "" || p.type !== "message" || p.role !== "user") return;
      const t = textOf(p.content);
      if (!injectedPrompt(t)) fallback = t;
    }
  });
  if (cwd !== "" && dir !== "" && cleanPath(cwd) !== cleanPath(dir)) {
    return ""; // a rollout of another project
  }
  return bound(or(first, fallback));
}

// ---- opencode ----

// opencode (v1) keeps one JSON file per session under
// ~/.local/share/opencode/storage/session/<project>. The storage tree
// holds every project's sessions, and the file says which one it is of; a
// child session is not the one in this terminal, and "New session -
// <timestamp>" is a default, not a name.
const opencodeDefaultTitle = /^(New|Child) session - \d{4}-\d{2}-\d{2}T/;

function parseOpencode(path, dir, text) {
  let o;
  try {
    o = JSON.parse(text);
  } catch (e) {
    return "";
  }
  if (!o || typeof o !== "object") return "";
  if (o.parentID) return ""; // a child session is not the one in this terminal
  if (o.directory && dir !== "" && cleanPath(o.directory) !== cleanPath(dir)) {
    return "";
  }
  if (opencodeDefaultTitle.test(String(o.title || ""))) return "";
  return bound(o.title);
}

// ---- the export ----

// agentTitle answers the host's ask, one branch per provider the manifest
// declares. It never throws: anything it cannot make sense of is a
// session without a name, and an empty title never clears one the host
// already shows.
export function agentTitle(req) {
  try {
    if (!req || typeof req !== "object") return { title: "" };
    const { provider, path, dir, text } = req;
    if (typeof text !== "string" || text === "") return { title: "" };
    let title = "";
    switch (provider) {
      case "pi":
        title = parsePi(path, dir, text);
        break;
      case "claude-code":
        title = parseClaude(path, dir, text);
        break;
      case "codex":
        title = parseCodex(path, dir, text);
        break;
      case "opencode":
        title = parseOpencode(path, dir, text);
        break;
    }
    return { title: typeof title === "string" ? title : "" };
  } catch (err) {
    return { title: "" };
  }
}

// ---- the functional fallback: agentSessions ----

// The `contributes.agents[].sessions` descriptors in plugin.json are the
// primary path: the host reads the files itself, in Go, without starting
// this VM. This export is the other half of the contract. A host that
// declares `export: "agentSessions"` instead of (or while debugging) a
// descriptor asks the plugin the same question, one file at a time.
//
// Request: { id, path, text, dir } — id is the agent's, provider/agent are
// accepted spellings, sessionId names a session the host already knows.
// Answer: { id, title, dir, updated, prompt }, or an array of them for a
// request carrying a list of files. It never throws, never reads the file
// system, and skips a line it cannot decode: a live file may end in a
// partial one.

// sessionPaths are the five field paths the declarative reader follows,
// kept here so both halves of the plugin agree on what a session is. They
// are the very strings in plugin.json, one entry per agent.
const sessionPaths = {
  pi: { id: "id", title: "name", dir: "cwd", updated: "timestamp", prompt: "message.content" },
  "claude-code": { id: "sessionId", title: "customTitle", dir: "cwd", updated: "timestamp", prompt: "message.content" },
  codex: { id: "payload.id", title: "payload.message", dir: "payload.cwd", updated: "timestamp", prompt: "payload.content" },
  opencode: { id: "id", title: "title", dir: "directory", updated: "time.updated", prompt: "title" },
};

// at is the host's field-path lookup in JS: keys and array indexes
// separated by dots, undefined for a path that is not there.
function at(o, path) {
  let v = o;
  for (const key of String(path || "").split(".")) {
    if (v === null || typeof v !== "object") return undefined;
    v = Array.isArray(v) ? v[Number(key)] : v[key];
  }
  return v;
}

// scalarAt is the host's scalar(): a JSON string or a number as text, ""
// for anything else, so an object at a title path does not become a name.
function scalarAt(v) {
  if (typeof v === "string") return v;
  if (typeof v === "number" && Number.isFinite(v)) return String(v);
  return "";
}

// records are the JSON objects of a file. Unlike lines() above, a bad
// line is skipped rather than ending the file, as the declarative reader
// and a half-written session need it to be. A whole-JSON file is one.
function records(text) {
  try {
    const o = JSON.parse(String(text));
    if (o && typeof o === "object" && !Array.isArray(o)) return [o];
  } catch (e) {
    // a JSONL file, or a truncated one: walk its lines below
  }
  const out = [];
  for (const raw of String(text).split("\n")) {
    const line = raw.trim();
    if (line === "") continue;
    try {
      const o = JSON.parse(line);
      if (o && typeof o === "object" && !Array.isArray(o)) out.push(o);
    } catch (e) {
      continue;
    }
  }
  return out;
}

// firstValue and lastValue are the host's rules for a file of lines:
// ID/Dir/Updated/Prompt take the first non-empty, Title the last. The
// value keeps its JSON type so a numeric time stays a number.
function firstValue(rs, path) {
  if (!path) return undefined;
  for (const o of rs) {
    const v = at(o, path);
    if (scalarAt(v) !== "") return v;
  }
  return undefined;
}

function lastValue(rs, path) {
  if (!path) return undefined;
  let out;
  for (const o of rs) {
    const v = at(o, path);
    if (scalarAt(v) !== "") out = v;
  }
  return out;
}

// promptAt is the first readable first question at a path, as the host's
// promptOf reads a string or a list of text parts. Prompts an agent wrote
// for itself do not name a session, exactly as in the four parsers above.
function promptAt(rs, path) {
  if (!path) return "";
  for (const o of rs) {
    const t = textOf(at(o, path));
    if (t !== "" && !injectedPrompt(t)) return bound(t);
  }
  return "";
}

// fileID is the host's last resort for an id: the file's name, without
// its extension.
function fileID(path) {
  const name = String(path || "").split(/[\\/]/).pop() || "";
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(0, dot) : name;
}

// parsedTitle asks the four readers above for the name a live tab shows.
// They still carry the project check and the title records a single field
// path cannot describe, so the functional path uses them as a fallback.
function parsedTitle(agent, path, dir, text) {
  switch (agent) {
    case "pi": return parsePi(path, dir, text);
    case "claude-code": return parseClaude(path, dir, text);
    case "codex": return parseCodex(path, dir, text);
    case "opencode": return parseOpencode(path, dir, text);
    default: return "";
  }
}

function emptySession() {
  return { id: "", title: "", dir: "", updated: "", prompt: "" };
}

// oneSession reads one file. A request with no text is a question about
// an agent, not a session; an empty answer never clears a name or a row.
function oneSession(req) {
  try {
    if (!req || typeof req !== "object" || typeof req.text !== "string" || req.text === "") {
      return emptySession();
    }
    const key = String(req.provider || req.agent || "");
    const named = String(req.id || "");
    const agent = key !== "" ? key : (Object.prototype.hasOwnProperty.call(sessionPaths, named) ? named : "");
    const p = sessionPaths[agent];
    if (!p) return emptySession();
    const { path, text, dir } = req;
    const rs = records(text);
    if (rs.length === 0 && String(req.sessionId || "") === "") {
      return emptySession(); // a file of nothing but broken lines is no session
    }
    const id = or(
      cleanTitle(String(req.sessionId || "")),
      cleanTitle(scalarAt(firstValue(rs, p.id))),
      cleanTitle(fileID(path)),
      Object.prototype.hasOwnProperty.call(sessionPaths, named) ? "" : cleanTitle(named)
    );
    const title = or(
      bound(scalarAt(lastValue(rs, p.title))),
      parsedTitle(agent, path, dir, text)
    );
    const wd = or(
      cleanTitle(scalarAt(firstValue(rs, p.dir))),
      dir ? cleanTitle(cleanPath(String(dir))) : ""
    );
    const updated = firstValue(rs, p.updated);
    return {
      id: id,
      title: title,
      dir: wd,
      updated: updated === undefined ? "" : updated,
      prompt: promptAt(rs, p.prompt),
    };
  } catch (err) {
    return emptySession();
  }
}

// agentSessions is the export a host may name in `export` (in place of a
// sessions descriptor), or call by hand while debugging a session file.
// It answers a session for one file and a list for a batch of them, and
// never escapes with an exception, whatever a half-written file holds.
export function agentSessions(req) {
  try {
    const batch = Array.isArray(req) ? req
      : (req && (Array.isArray(req.files) || Array.isArray(req.sessions) || Array.isArray(req.items))
        ? (req.files || req.sessions || req.items) : null);
    if (batch) {
      const out = [];
      for (const f of batch) {
        const s = oneSession(f && typeof f === "object" ? { ...req, ...f } : { ...req, text: f });
        if (s.id !== "") out.push(s);
      }
      return out;
    }
    return oneSession(req);
  } catch (err) {
    return Array.isArray(req) ? [] : emptySession();
  }
}
