# Todo Scanner — Lumen 示例插件

A runnable plugin that scans the current project for a configurable pattern
(`TODO` by default) and shows the matches in a dock tool window. It is a
**starting point**, not a complete reference of every contribution point —
see `docs/USING-PLUGINS.md` for the full guide.

## Install

The app ships with **no preinstalled plugins**. Install this one in either way:

- **GUI**: `cd examples && zip -r todo-plugin.zip todo-plugin`, then
  Settings → Plugins → `+` → *From Zip Archive…*.
- **Folder** (development): copy the directory into the data directory as
  `plugins/todo` — the folder name should match the manifest `id`:

  ```bash
  # Linux
  cp -r examples/todo-plugin ~/.config/Lumen/plugins/todo
  # macOS
  cp -r examples/todo-plugin ~/Library/Application\ Support/Lumen/plugins/todo
  ```

Then refresh the Plugins page (or restart Lumen).

## What it demonstrates

| File | Demonstrates |
|---|---|
| `plugin.json` | Top-level fields, `permissions.workspaceRead`, two `settings[]` items (`pattern`, `maxFiles`), `commands` with `defaultKey`, `menus`, `contextKeys`, a `kind: tree` tool window, a custom `languages` entry (`.todo` with `#` comments) |
| `index.js` | `onCommand`, `toolWindowData` (re-scanning for every `reason`), `setSetting`, `host.storage`, `host.workspace`, `host.setContext` |
| `locales/zh-Hans.json` | Localized plugin name and setting labels |

Not covered here: `contextMenus`, `statusBar`, `keybindings`, `webview` tool
windows, and `markdownBlockRenderers`.

## Behaviour

`toolWindowData` answers a fresh scan on every ask, so the list follows the
code: saving, creating or removing a file, switching projects, the scan
command and the panel's refresh button all show what the files contain now.
Rows are cached in `plugin-data/todo/storage.json` per project root only so
the first frame after a restart has something to show while the file index is
still being listed.

Plugin data lives in `<data dir>/plugin-data/todo/` (`settings.json`,
`storage.json`, `granted.json`). See `docs/USING-PLUGINS.md` for the directory
layout, the Host API, and troubleshooting.
