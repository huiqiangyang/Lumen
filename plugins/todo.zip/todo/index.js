// Todo Scanner: finds TODO-style markers in the files of the project.
//
// It shows what it found in its tool window, counts them in the status bar
// through its context key, and opens the place of a row when it is chosen.
//
// The host asks toolWindowData whenever the rows may be old: the window
// opens, the panel's refresh button is pressed, a file is saved, the
// project's files are listed, or the project switches. Every ask reads the
// files again, so the list follows the code rather than a snapshot of it.

// Text files only: a scan is cheap, but reading a binary is not.
const BINARY = /[\u0000-\u0008\u000e-\u001f]/;
const SKIP = /\.(png|jpe?g|gif|webp|bmp|ico|icns|pdf|zip|gz|tar|tgz|xz|bz2|7z|rar|jar|war|exe|dll|dylib|so|a|o|class|wasm|mp[34]|wav|flac|ogg|woff2?|ttf|otf|eot|mov|mp4|avi|mkv)$/i;

/** The rows of the last scan, kept so choosing one costs nothing. */
let rows = [];
/** The project they are of, and whether its kept rows were restored. */
let root = null;
let restored = false;
/** The rows last written to storage, so a scan that changed nothing writes nothing. */
let saved = "";
/** Whether this project's files have been listed, to tell "not yet" from "empty". */
let listed = false;
/** A guard, though the host serialises its calls into a plugin. */
let scanning = false;

const setting = (key, fallback) => {
  const v = host.setting(key);
  return v === undefined || v === null || v === "" ? fallback : v;
};

// rowOf makes a row of one line of a file.
function rowOf(path, line, text, needle) {
  const at = text.toLowerCase().indexOf(needle);
  const label = text.trim();
  return {
    label: label.length > 200 ? label.slice(0, 200) + "…" : label,
    detail: `${path}:${line + 1}`,
    path,
    line: line + 1,
    col: at >= 0 ? at + 1 : 0,
  };
}

// scan reads the listed files of the project and answers the rows that match.
function scan(files) {
  const pattern = String(setting("pattern", "TODO")).trim();
  if (pattern === "") return [];
  const needle = pattern.toLowerCase();
  const maxFiles = Number(setting("maxFiles", 800)) || 800;

  const found = [];
  let read = 0;
  for (const path of files) {
    if (read >= maxFiles) break;
    if (SKIP.test(path)) continue;
    let text;
    try {
      text = host.workspace.readFile(path);
    } catch (e) {
      // A file the app cannot read, as one removed since it was listed.
      continue;
    }
    read++;
    if (!text || BINARY.test(text)) continue;
    const lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].toLowerCase().includes(needle)) {
        found.push(rowOf(path, i, lines[i], needle));
      }
      // One file of a huge number of matches is not worth the whole scan.
      if (found.length >= 500) break;
    }
    if (found.length >= 500) break;
  }
  return found;
}

// forProject forgets rows of another project: host.workspace answers for
// the window the host last asked about, which is not always this one.
function forProject() {
  const at = (host.window() || {}).projectRoot || "";
  if (at === root) return;
  root = at;
  rows = [];
  restored = false;
  saved = "";
  listed = false;
}

// rescan reads the files anew and keeps what it found. It never calls
// host.ui.invalidate: toolWindowData is itself the answer to an
// invalidation, and invalidating from inside it would ask, scan and
// invalidate again forever. The host asks again after a command or a
// changed setting, both of which run on the thread that draws.
function rescan() {
  if (scanning) return;
  const files = host.workspace.files() || [];
  if (files.length > 0) listed = true;
  if (!listed) {
    // A project's files are listed in the background. Until they are,
    // keep the rows we have; the host asks again once they are listed.
    // Once listed, an empty list really is an empty project, and a scan
    // clears the rows of files that went away.
    if (root !== "") console.log("todo: the project lists no files to read yet");
    host.setContext("todo.hasResults", rows.length > 0);
    return;
  }
  scanning = true;
  try {
    rows = scan(files);
    const json = JSON.stringify({ root, rows });
    if (json !== saved) {
      host.storage.set("rows", { root, rows });
      saved = json;
    }
    host.setContext("todo.hasResults", rows.length > 0);
  } catch (e) {
    rows = [];
    host.setContext("todo.hasResults", false);
    console.log("scan failed: " + (e && e.message ? e.message : String(e)));
  } finally {
    scanning = false;
  }
}

export async function onCommand({ id }) {
  if (id !== "todo.scan") return;
  forProject();
  rescan();
  // The host asks toolWindowData again once this command returns.
  return rows.length;
}

export async function toolWindowData({ id }) {
  if (id !== "todo.window") return { rows: [] };
  forProject();
  // On the first ask of a project the rows kept from the last run show at
  // once. A scan follows them, as soon as the host has listed its files.
  if (!restored) {
    restored = true;
    const kept = host.storage.get("rows");
    if (kept && kept.root === root && Array.isArray(kept.rows) && kept.rows.length > 0) {
      rows = kept.rows;
      saved = JSON.stringify({ root, rows });
    }
  }
  // A refresh, a save, a new file, a new project: every ask answers what
  // the files say now, not what they said at the last scan.
  rescan();
  if (rows.length === 0) {
    return { rows: [], empty: "Nothing found in this project" };
  }
  // Grouped by file, as a tree: the file, then the lines found in it.
  const byFile = new Map();
  for (const row of rows) {
    const at = byFile.get(row.path);
    if (at) at.lines.push(row);
    else byFile.set(row.path, { lines: [row] });
  }
  const tree = [];
  for (const [path, group] of byFile) {
    tree.push({
      label: path,
      detail: `${group.lines.length}`,
      path,
      depth: 0,
    });
    for (const row of group.lines) {
      tree.push({ ...row, depth: 1, detail: `:${row.line}` });
    }
  }
  return { rows: tree };
}

export function setSetting({ key }) {
  // A new pattern means the rows there are were found by the old one.
  // The host asks toolWindowData again once this setting is written.
  if (key === "pattern") {
    forProject();
    rescan();
  }
}
