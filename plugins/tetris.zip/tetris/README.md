# Tetris — Lumen 示例插件

A playable Tetris that lives in a **bottom dock tab**. It is one
`kind: webview` tool window backed by a single, self-contained HTML page:
the 10×20 board, canvas drawing, input, sound and translations are all in
`tetris.html`. The host mounts that file as an untrusted native WebView.

## Install

The app ships with **no preinstalled plugins**. Install this one in either way:

- **GUI**: `cd examples && zip -r tetris-plugin.zip tetris-plugin`, then
  Settings → Plugins → `+` → *From Zip Archive…*.
- **Folder** (development): copy the directory into the data directory as
  `plugins/tetris` — the folder name should match the manifest `id`:

  ```bash
  # Linux
  cp -r examples/tetris-plugin ~/.config/Lumen/plugins/tetris
  # macOS
  cp -r examples/tetris-plugin ~/Library/Application\ Support/Lumen/plugins/tetris
  ```

Then refresh the Plugins page (or restart Lumen). Find **Tetris** in the
bottom dock's tab list, or in the tool-window menu in the status bar, and
open it.

## Play

Click **Start** (or press `Enter`). Clicking the page also gives it the
keyboard: a WebView only receives keys once it has focus. The on-screen
buttons work with a mouse or a touchscreen as well. Drag the dock's top
edge up for a bigger board — the cells scale to the space the tab gets.

| Key | Action |
|---|---|
| `←` / `→` | Move (hold to repeat) |
| `↓` | Soft drop (+1 per row) |
| `Space` | Hard drop (+2 per row) |
| `↑` / `X` / `Z` | Rotate clockwise / clockwise / counter-clockwise |
| `C` | Hold / swap the current piece (once per piece) |
| `P` | Pause / resume |
| `R` | New game |
| `Enter` | Start or resume |

Rules: a 7-bag randomizer, SRS rotation with wall kicks, a ghost piece,
three previews, hold, combos, level-ups that speed up gravity, a 500 ms
lock delay, and a high score. The score table is the classic
100 / 300 / 500 / 800 × level for 1–4 lines, plus a combo bonus.
The UI speaks English, 简体中文 and 日本語 (the button in the top-right
cycles through them, and the first choice follows `navigator.language`).

## What it demonstrates

| File | Demonstrates |
|---|---|
| `plugin.json` | One `contributes.toolWindows` entry of `kind: webview` with a **local** `html` path; `side: bottom` is where the host puts every contributed dock tab |
| `index.js` | A declarative plugin still needs a compilable `main`; nothing calls it |
| `tetris.html` | An untrusted WebView page: inline CSS + two inline scripts, canvas drawing, `requestAnimationFrame`, keyboard/pointer input, WebAudio, `prefers-color-scheme`, and guarded `localStorage` |
| `locales/*.json` | Plugin `name` and tool-window `title` translations (zh-Hans / ja) |
| `tests/*.test.js` | The rules run in a bare `vm`; the page runs against a small DOM stand-in |

See `docs/USING-PLUGINS.md` §3.3 for the `toolWindows` contract.

## Permissions

None. The manifest declares no `network`, `process` or `workspaceRead`
access. The page loads no sibling files, makes no requests and cannot call
host methods: `newPluginWebView` creates it with
`mygo.PageOptions{Untrusted: true}`, and the host resolves `html` so it
cannot point outside the plugin's own directory.

## Limitations

- **A native WebView is required.** On a backend without one (headless
  tests, some remote sessions) the dock tab shows a card with the resolved
  page path and `native WebView is unavailable` instead of the game. There
  is no text-mode fallback; WebView mounting has not been smoke-tested on
  real hardware yet (see `docs/USING-PLUGINS.md` §11).
- **No host bridge.** An untrusted page cannot read `host.storage`,
  `host.setting()` or the Lumen theme. The best score and the language /
  mute preferences are kept in `localStorage` when the web engine allows
  it; otherwise they last only for the lifetime of the page. The page
  follows the OS light/dark preference, not Lumen's own theme.
- **Keyboard focus.** Keys the page leaves unhandled go back to the native
  UI, so Lumen's shortcuts still work. If the arrow keys move the editor
  instead of the piece, click the playfield once (there is a hint for this
  in the page).
- Sound is generated with WebAudio and is silently skipped when the window
  has no audio device.

## Performance

The page is idle almost all of the time. Its `requestAnimationFrame` loop
repaints the canvas **only when the visible state changes** (input, a gravity
step, a lock, a line clear): the engine bumps a version counter on every
event and the frame skips drawing while it is unchanged. Outside a running
game the loop stops entirely and is restarted by input; when the document
becomes hidden the game pauses itself. Measured over 3600 frames (60 s at
60 fps) with `tests/bench.js`, against a no-op canvas context:

| | before | after |
|---|---|---|
| JS time | 87.5 ms | 8.2 ms |
| board repaints | 3600 | 74 |
| cell fills | 84,424 | 1,766 |

Real canvas rasterisation adds to both, which is exactly why the repaints
were removed. The host side is lighter still: a `webview` tool window never
calls `toolWindowData`, so the plugin's moejs VM is never started (only
`index.js` is compiled once at load), there are no timers, no workspace
scans and no `host.ui.invalidate()` calls. The dock tab is only drawn while
it is open. The page itself runs in the platform's WebView process, not in
Lumen's main thread, but it does cost that process some memory.

## Tests

```bash
# Rules + page smoke tests (Node 18+)
node --test examples/tetris-plugin/tests/*.test.js

# Frame cost over 60 s of simulated frames
node examples/tetris-plugin/tests/bench.js

# Host integration: discovery, dock tab, local HTML target, headless and
# native WebView mounting
go test ./cmd/lumen -run TestTetris
```

## Uninstall

Settings → Plugins → 🗑 on the Tetris card. The `plugin-data/tetris/`
directory is kept by the host, as for every plugin. To disable the game
without uninstalling, switch the card off or move
`plugins/tetris/` out of the data directory.
