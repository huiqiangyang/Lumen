// Tetris is a self-contained webview tool window: everything the game does
// lives in tetris.html, which the host mounts as an untrusted native WebView.
// There is no host API to call from the page and no plugin-side state, so
// this module only has to exist: Lumen compiles `main` when it loads a
// plugin, even a purely declarative one (see docs/USING-PLUGINS.md §3.3).
export function activate() {}
