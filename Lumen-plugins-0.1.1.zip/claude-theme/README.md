# Claude Theme — Lumen 示例插件

这个插件把原先写在 `cmd/lumen/theme.go` 里的内置 **Claude** 主题外置成了纯声明式的插件主题：`plugin.json` 的 `contributes.themes` 描述明暗两套颜色 token，宿主用 `themeTokens.go` 的 adapter 把它们还原成 `*palette`，再走既有的 `bringTheme()` 链路。因此它和 Lumen 自带主题一样出现在主题选择器、设置页的主题卡片和 View 菜单里，`accentedDialog: true` 也让对话框边框使用强调色（与原来的 `ThemeProvider` 一致）。

**当前配色是 Vivid（高对比 / 鲜艳）版。** 底色压得更深（暗色）或提得更亮（亮色），正文、行号与次要文字提亮，橙色强调色和语法色饱和度更高，边框、选中、查找匹配、缩进引导等辅助色也更明确。明暗两套里正文、次要文字、行号、强调色与所有语法色对各自背景的对比度都不低于 4.5:1（WCAG AA），按钮文字对按钮底色同样如此。它不再是旧内置 Claude 调色板的逐字段复刻，见下「与旧内置主题的关系」。

## 安装

Lumen 不预装任何插件。两种安装方式：

- **文件夹（开发时用）**：把整个目录复制到数据目录的 `plugins/claude-theme/`，目录名与 manifest 的 `id` 一致，然后刷新 Settings → Plugins（或重启 Lumen）。

  ```bash
  # Linux
  cp -r examples/claude-theme-plugin ~/.config/Lumen/plugins/claude-theme
  # macOS
  cp -r examples/claude-theme-plugin ~/Library/Application\ Support/Lumen/plugins/claude-theme
  ```

- **Zip**：`cd examples && zip -r claude-theme-plugin.zip claude-theme-plugin`，然后在 Settings → Plugins → `+` → *From Zip Archive…* 中选择它，刷新插件页后即可在主题选择器里看到 Claude。

`index.js` 只是最小的 ESM 文件：安装时插件宿主会编译 `main`，但这个主题没有任何需要调用的代码。

## 配色一览

| | Dark | Light |
|---|---|---|
| 背景 editor / chrome | `#100e0c` / `#090807` | `#fffdf8` / `#f7f1e6` |
| 正文 text / muted / faint | `#fff8ef` / `#c2b8a8` / `#8f8679` | `#17120e` / `#5b5044` / `#6f6353` |
| 强调 accent | `#ff8033` | `#b84000` |
| 按钮 fill / fillText | `#ff8033` / `#140d09` | `#e35a12` / `#140d09` |
| 选中 selection | `#5f6dff59` | `#4f5fe840` |
| 关键字 / 字符串 / 数字 | `#a68bff` / `#7ce38b` / `#ffd23f` | `#4b3fd6` / `#0a7530` / `#8a5000` |
| 新增 / 修改 / 删除 | `#35e06e` / `#ffc233` / `#ff4d5e` | `#087a38` / `#945c00` / `#bf1233` |

强调色与语法色刻意保持「暖橙 + 冷紫 / 青」的对照：选区用靛蓝而不是橙色，避免和强调色、查找高亮混成一团；亮色外观的橙、绿、琥珀都压暗到能在象牙白底上读清，暗色外观则把同色相提亮。终端 16 色也按同样的明暗思路各给一套，`ansi[0..7]` 是普通色，`ansi[8..15]` 是亮色。

## Token 是怎么生效的

- `dark` / `light` 各自有 `colors`、`syntax`、`ansi` 三部分。颜色值是 `#rrggbb`（不透明）或 `#rrggbbaa`（第 4 个字节是 0–255 的 alpha）；例如悬停的 12% 白写成 `#fff5e61f`，强调色的 70% 透明写成 `#ff8033b3`。
- `mono` 是主题描述符顶层的布尔标记，**不在** `dark` / `light` 的 `colors` 里：`mono: true` 让整窗使用代码字体、文件图标按调色板着色而不按语言着色。宿主把它写入明暗两份 palette，它不是颜色 token；若误写进 `colors`，会因「未知字段名」在激活时报错。
- **这是 partial overlay（局部覆盖）**：宿主先复制 `darkPalette()` / `lightPalette()`，只覆盖这里写出的字段，最后调用 `derive()` 重新推导由其他颜色生成的字段。没有列出的字段自动继承 Lumen 对应明暗调色板，不会变成零值（否则控件会画成黑色）。`syntax` 的名字必须是 `internal/highlight` 里的 kind 名（如 `Keyword`、`String`、`Heading`），`ansi` 最多 16 个，按索引写入。
- **按钮的悬停 / 按下色跟着 `fill` 走**：只写 `colors.fill` 而不写 `fillHover` / `fillPressed` 时，宿主按明暗用 `fill` 的 `Mix` 补上这两色（与 Lumen 自带调色板同一公式），因此换掉按钮主色不会让悬停仍闪 Lumen 的蓝。本插件两套都显式写出了 `fillHover` / `fillPressed`，宿主会原样保留这组手调值。
- 未知字段名、非法颜色、未知 syntax kind 或超过 16 个 ANSI 都会在**激活时报错并写入日志**，并且不会注册任何东西（主题和它的命令都不会留下半套状态）。
- 宿主为 dark / light **各缓存一个 `*palette` 指针**。`paletteFade.step()` 用指针身份判断渐变是否要重启，所以每次 `Palette()` 都返回同一个指针；`p.dark` 也随窗口外观取对应的调色板，`applyTheme()` 据此设置窗口的 `Dark`。
- **停用插件后**主题和 `view.theme.*` 命令一起撤销，`paletteFor()` 回退到 Lumen 的 `darkPal` / `lightPal`，窗口渐变回到 Lumen 配色。旧设置值 `claude` 不再对应内置主题；本插件的 ID 是 `claude-theme.claude`。

## 与旧内置主题的关系

Vivid 版是在原内置 Claude 调色板的骨架上**有意识地调过**的，不再是逐字段迁移：象牙白 / 近黑的底色关系、Claude 橙、蓝紫关键字与 `mono: true` / `accentedDialog: true` 两个行为标记都保留，变化集中在亮度、饱和度与辅助色的可见度（详见「配色一览」）。宿主侧的 `derive()` 与 `legible()` 逻辑没有改动：`modifiedFg` / `addedFg` / `removedFg` / `dangerFg` 仍按 4.5:1 推导，`selected` / `selectedDim` / `cursor` 仍由选区与强调色生成；因此想调回柔和的老配色，只需把 `plugin.json` 里对应的颜色换回去，不用改宿主代码。

**Clawd 吉祥物与 Clauding spinner 不随之外置，已一并删除**（`clawd.go`、`clauding.go` 以及内置的 mascot 注册都已移除）。通用的 mascot 绘制机制仍保留，插件若需要可以自行通过 `mascots` 扩展点贡献角色；没有角色时欢迎页显示 Lumen logo，状态栏显示普通 spinner。
