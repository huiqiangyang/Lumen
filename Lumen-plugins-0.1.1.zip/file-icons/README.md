# File Icons — Lumen 示例插件

这个插件把原先 `cmd/lumen/icons.go` 的 `fileIcon()` 里那一整段
「扩展名 / 文件名 → 图标 + 配色」switch 表搬到了 `plugin.json` 的
`contributes.fileIcons`。核心只保留：

- `lucide()` 辅助函数与所有 `icon*` 全局变量；
- `fileIconProviders` 注册表、`FileIconProviders()`、
  `RegisterFileIconProvider()`；
- `RegisterPluginFileIcon()`：把插件声明的 descriptor 变成 provider；
- `langColor()`：dark / light / mono 三种调色板下的图标着色；
- `fileIcon()` 本身：插件匹配优先，没有匹配时统一返回通用
  `iconFile` 与 `p.muted`。

## 安装

Lumen 不预装任何插件，二选一：

- **目录**（开发时用）：把本目录复制到数据目录的 `plugins/file-icons`
  （目录名应与 `plugin.json` 的 `id` 一致）：

  ```bash
  # Linux
  cp -r examples/file-icons-plugin ~/.config/Lumen/plugins/file-icons
  # macOS
  cp -r examples/file-icons-plugin ~/Library/Application\ Support/Lumen/plugins/file-icons
  ```

- **Zip**：`cd examples && zip -r file-icons-plugin.zip file-icons-plugin`，
  然后在「设置 → 插件 → + → 从 Zip 安装…」中选择它。

之后刷新插件页或重启 Lumen。

## 未安装时会怎样

所有文件都显示同一个通用 `iconFile`，颜色是 `p.muted`：资源管理器、
标签页、面包屑、搜索结果、快速打开等所有调用 `fileIcon()` 的地方都
一样。禁用 / 卸载插件后也是如此；核心没有任何内置映射表可以回退。

插件提供了 `dark` / `light` 两个 `#rrggbb` 值时，宿主用
`langColor(p, dark, light)` 取色（mono 调色板另有自己的一支）；
**没有给 `dark` / `light` 时图标就用 `p.muted`**。原表里的
dotfile（`.gitignore`、`.editorconfig` 等）和 `*.lock` / `*.sum`
本来就是 muted / faint，这两条 descriptor 因此不带颜色。

## descriptor 的数据形状

每条 descriptor 的 `id` 都带 `file-icons.` 前缀（宿主也接受裸 ID 并
自动补前缀）；`match` 是 glob 数组，由宿主的 `path.Match` 对
「小写化的文件名（`filepath.Base`）」逐个匹配，任一命中即返回该图标；
`svg` 是完整的 `<svg xmlns=... width=24 height=24 viewBox="0 0 24 24"
fill="none" stroke="currentColor" stroke-width="2" ...>` 标记，
与 `lucide(body)` 拼出来的字符串一致。

SVG 标记与颜色都是纯数据，跨 JS 边界安全；解析 SVG、匹配 glob、
着色和绘制仍然全部由宿主完成，插件不向窗口传任何 Go 值。SVG 解析
失败、glob 非法、颜色不是合法十六进制时，`RegisterPluginFileIcon()`
返回 error 而不会 panic，该条图标会被跳过。

descriptor 的顺序有意义：宿主按注册顺序取第一个匹配的 provider。
精确文件名、`.env*` 与各扩展名按旧 switch 的顺序在前，`.*` 这条
dotfile descriptor 放在最后。这样 `go.mod` / `go.sum` / `go.work` 与
`*.go`、`package.json` / `bun.lock` / `pnpm-lock.yaml` 与 `*.json*`
等精确名先于 `*.sum`、`*.lock`、`*.yaml` 命中，而带第二段扩展名的
点文件（如 `.yarnrc.yml`、`.foo.md`）也能落到 `*.yml`、`*.md` 的图标；
只有 `.gitignore`、`.editorconfig` 这类纯点文件最终落到 `.*`。若把
`.*` 提前，它会把它们全部截成 muted 设置图标。

相同图标、相同颜色的多个扩展名合并进同一条 `match` 数组：原表的
15 个精确文件名、64 个扩展名和 2 条特殊规则（`.env*`、`.*` dotfile）
共 81 个 glob，合并为 21 条 descriptor。dotfile 用 `.*` 覆盖，这是
`path.Match` 能表达的最接近旧规则的形式；副作用是极少数恰好叫
`.go`、`.json` 之类的纯点文件会命中排在前面的扩展名图标，而不是
通用设置图标。

配套示例是 `examples/languages-pack-plugin/`（语言定义外置）。
