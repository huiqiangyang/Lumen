// File icons are data, not code: every descriptor in plugin.json carries
// globs on the file's base name, full SVG markup, and optional dark and
// light colors. The host parses the SVG and tints it in the window's
// palette, so the plugin's own JavaScript has nothing to draw.

export function activate() {}
