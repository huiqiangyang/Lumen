# Agent Session Titles — Lumen 示例插件

本插件把原先内置在 `cmd/lumen/agenttitle.go` 里的 **4 个外部 agent 私有 session 文件解析器**
（`pi`、`claude-code`、`codex`、`opencode`）外置出来。这些私有格式不由 Lumen 定义、会随上游
版本变化，不该由内核感知：核心现在对它们的 session 文件一无所知。

## 分工

- **宿主（内核）负责发现文件**：按 `plugin.json` 里 `agentTitleProviders` 每条的 `folders`
  glob 在用户家目录下展开目录，用 `match` 正则匹配文件基名，读入发生变化的文件**全文**，
  调用插件导出的 `agentTitle({ provider, path, dir, text })`。
- **插件只负责解析格式**：返回 `{ title: "<会话名>" }`，解析不到返回 `{ title: "" }`。
  插件拿不到 `*app`、不能自己读文件系统，唯一接触到的路径就是调用参数里的 `path`/`dir`。
  所有解析都包在 try/catch 里，任何异常都不会逃逸成 `{ title: "" }` 之外的回答。

`dir` 是会话的工作目录：pi 与 Claude Code 按项目分目录存放，Codex 与 opencode 在文件里
记录工作目录，插件据此把别的项目的文件排除掉。

## 未安装本插件时

核心仍按终端标准协议显示会话标题：**OSC 7501 的 `title=` / `app=`**，然后是 **OSC 0/2
窗口标题**，最后才退回 agent 的名字。核心内置的 reader 注册表启动时为空，不装任何插件
窗口标题照样工作；只是「agent 没写窗口标题时去读它的 session 文件」这条兜底路径没有了。

## 安装

应用不预装插件。两种方式：

- **目录**（开发）：把本目录复制到数据目录 `plugins/agent-sessions/`（目录名与 manifest
  的 `id` 一致）：

  ```bash
  # Linux
  cp -r examples/agent-sessions-plugin ~/.config/Lumen/plugins/agent-sessions
  # macOS
  cp -r examples/agent-sessions-plugin ~/Library/Application\ Support/Lumen/plugins/agent-sessions
  ```

- **Zip**：`cd examples && zip -r agent-sessions-plugin.zip agent-sessions-plugin`，然后
  设置 → 插件 → `+` → *从 Zip 安装…*。

装好后刷新插件页（或重启 Lumen）。

## 命名空间：为什么 id 是裸的 agent 名

`agentTitleProviders` 每条的 `id` **不加** `插件id.` 前缀，直接写 `pi` / `claude-code` /
`codex` / `opencode`。查找键是 agent 自己的名字——它来自命令行、OSC 0/2 窗口标题和 OSC
7501 的 `app=`，是 agent 们定义的全局命名空间，不是插件能改的；宿主内核按这个名字查
reader（先查别名、再查 ID），加了前缀就永远查不到。谁先注册谁占用：`registerAgentTitle`
会拒绝任何与已有 reader 的 ID 或别名重名的注册，manifest 里的 `aliases` 也在同一张表里去重。

## 四个 provider 的路径与正则（与原内置 reader 逐项核对）

| provider | aliases | folders（家目录下 glob） | match |
|---|---|---|---|
| `pi` | `π` | `.pi/agent/sessions/*` | `\.jsonl$` |
| `claude-code` | `claude`、`claude code` | `.claude/projects/*` | `\.jsonl$` |
| `codex` | 无 | `.codex/sessions/*/*/*`（按年/月/日分片） | `^rollout-.*\.jsonl$` |
| `opencode` | `oc`、`open code` | `.local/share/opencode/storage/session/*` | `^ses_.*\.json$` |

原 reader 里各 agent 的环境变量覆盖（`PI_CODING_AGENT_DIR`、`CLAUDE_CONFIG_DIR`、
`CODEX_HOME`、`XDG_DATA_HOME`）在 glob 形式下不再单独支持：glob 固定相对家目录展开。
这四个变量都只是把整棵树挪个位置，需要的人可以建符号链接。

## 已知取舍

- **Codex 的 `session_index.jsonl` 线程名查表没有移植**。原 reader 会用 rollout 文件名里
  的会话 id 去 `~/.codex/session_index.jsonl` 里查人起的线程名；插件不能读文件系统，宿主
  也只传被 `match` 匹配中的 session 文件，所以这条查表路径在宿主/插件契约下不可表达。
  现在的回退顺序是：首条用户消息 → 首条 user response item，与原实现的兜底一致，丢的只是
  索引里 AI 生成的线程名。
- **Claude Code 的旧版 `title` 字段**只从类型名本身含 "title" 的记录里读（附件、工具结果
  自带的 `title` 不算），与原实现一致。

## 上游格式变化时

只需更新本插件的 `index.js`（以及必要时 `plugin.json` 的 glob/正则），重装即可，不用改
Lumen 本体。`pi` / `claude-code` / `codex` 的 JSONL 逐行解析、注入提示过滤（
`<environment_context…`、`AGENTS.md` 等、`/` 命令）、80 字符截断、opencode 的
`^(New|Child) session - \d{4}-…` 默认标题过滤，都在这里。

运行环境是普通插件 VM（256 MiB、30s 调用超时）；解析一次 session 文件远在超时之内。
