# Languages Pack — Lumen 示例插件

这个插件把原先硬编码在核心里的语言定义整体搬到了 `plugin.json`：

- `cmd/lumen/languages.go` 里的 14 种内置语言（`builtinLanguages`）；
- `cmd/lumen/completion.go` 里的 `completion*Words` 关键字词表；
- `cmd/lumen/editing.go` 里的 `lineComments` 注释符大表。

核心现在只保留三个注册表与查找逻辑：`languageRegistry`、
`LanguageForPath()`、`RegisterLanguage()`，以及 `completionKeywords()` /
`commentFor()` 对注册表的最小查询。语言的名字、文件关联、行注释符和
关键字都由插件在 `contributes.languages` 中声明，宿主启用插件时调用
`RegisterLanguage()` 注册；`index.js` 是纯声明式插件，不执行任何逻辑。

## 安装

Lumen 不预装任何插件，二选一：

- **目录**（开发时用）：把本目录复制到数据目录的 `plugins/languages-pack`
  （目录名应与 `plugin.json` 的 `id` 一致）：

  ```bash
  # Linux
  cp -r examples/languages-pack-plugin ~/.config/Lumen/plugins/languages-pack
  # macOS
  cp -r examples/languages-pack-plugin ~/Library/Application\ Support/Lumen/plugins/languages-pack
  ```

- **Zip**：`cd examples && zip -r languages-pack-plugin.zip languages-pack-plugin`，
  然后在「设置 → 插件 → + → 从 Zip 安装…」中选择它。

之后刷新插件页或重启 Lumen。禁用 / 卸载插件后，语言贡献会被全部撤回，
注册表重新变空。

## 未安装时会怎样

核心仍然可用：

- `cmd/lumen/completion.go` 的 `scanWords()` 通用词频补全照常工作，
  从当前文档里取词；
- `internal/highlight` 的 Chroma 语法高亮照常工作，它不依赖语言注册表；
- 缩进、括号配对等编辑行为照常工作。

缺少的是「扩展补充能力」：

- 没有预设关键字补全（例如输入 `ran` 不再补出 `range`）；
- 注释切换（`⌘/` / `Ctrl+/`）什么都不做，因为 `commentFor()` 只查
  `LanguageForPath(d.path).LineComment`，没有贡献就返回空串。

装回本插件即可恢复两者。配套示例是 `examples/file-icons-plugin/`
（文件图标外置）。

## 语言 ID 必须带命名空间

`RegisterLanguage()` 要求贡献 ID 以 `插件ID + "."` 开头，且拒绝由
`"lumen"` 贡献。因此 `plugin.json` 里是 `languages-pack.go`、
`languages-pack.python` 等，而不是裸的 `go`、`python`。写新语言时请
沿用这个前缀，否则宿主会报错并跳过该条语言。

`extensions` / `filenames` 决定文件匹配（精确文件名优先，扩展名次之，
同权重时按 Order 与注册顺序确定性决胜）；`lineComment` 决定注释切换，
`keywords` 决定关键字补全。`html` 的 `lineComment` 为空，所以 HTML / XML
一类文件本来就没有行注释切换，这一点与外置前一致。

迁移的数据来自原切片的逐条转写：14 种语言、10 组关键字词表
（`strings.Fields` 按空白分词），共 647 个按语言展开的关键字条目。
