// The languages pack is purely declarative: every language, its file
// associations, its line comment and its keywords live in plugin.json.
// The host registers those contributions when it enables the plugin, so
// there is nothing for the plugin's own JavaScript to do.

export function activate() {}
