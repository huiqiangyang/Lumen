// gopls for Go: contributes the Go language server and a command that
// installs it with the user's own Go toolchain.
//
// The installer is deliberately one process and one answer: the host gives
// an installer command a long budget (ten minutes, not the usual thirty
// seconds), so `go install` may compile gopls to completion inside this
// call. stdout is read line by line because that is what host.spawn offers;
// `go install` writes its progress to stderr, which host.spawn keeps in a
// buffer and answers through errorOutput() once the child exits. Nothing is
// streamed: the panel only shows the thrown error text on failure, and
// refreshes the row on success.
//
// The manifest names `gopls` rather than an absolute path: the path is the
// user's own ($GOBIN, or $(go env GOPATH)/bin when GOBIN is unset), and a
// bare name is looked up on PATH. The `gopls` process permission covers the
// server binary; `go` covers this installer.

const GO_INSTALL = ["install", "golang.org/x/tools/gopls@latest"];

// reasonOf makes any thrown value readable in an error the panel can show.
function reasonOf(err) {
  if (err === undefined || err === null) return "unknown error";
  if (typeof err === "string") return err;
  return err.message ? String(err.message) : String(err);
}

// run starts a permitted program, drains its stdout to end, waits for its
// exit, and answers the exit code with stdout and stderr together.
async function run(command, args) {
  const child = host.spawn(command, args);
  let output = "";
  for (;;) {
    const line = await child.readLine();
    if (line === null) break;
    output += line + "\n";
  }
  const code = await child.wait();
  const stderr = child.errorOutput();
  if (stderr) output += stderr.endsWith("\n") ? stderr : stderr + "\n";
  return { code, output: output.trim() };
}

export async function installGo() {
  let result;
  try {
    result = await run("go", GO_INSTALL);
  } catch (err) {
    throw new Error(
      "could not run go: " + reasonOf(err) +
      " — install Go from https://go.dev/dl and allow this plugin to start programs in Settings → Plugins"
    );
  }
  if (result.code !== 0) {
    // The last lines are the useful ones; `go` puts the reason there.
    throw new Error(
      result.output === ""
        ? "go install exited with code " + result.code
        : result.output
    );
  }
  return {
    ok: true,
    output: result.output === ""
      ? "gopls installed; go put it in $GOBIN, or $(go env GOPATH)/bin when GOBIN is unset"
      : result.output,
  };
}

// onCommand runs the installer when the panel, the command palette, or
// `lumen run lsp-gopls.install` asks for the contributed command. The
// installer descriptor names this command id; the host runs it through the
// plugin's own commands, so this export (not installGo's name) is what the
// command registry finds.
export async function onCommand({ id }) {
  if (id === "lsp-gopls.install") return installGo();
}
