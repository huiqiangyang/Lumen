# Go Language Server — Lumen 示例插件

A plugin that contributes **gopls** as Lumen's Go language server, and an
install command that puts it there with the user's own Go toolchain. It
ships no binary: the plugin declares the server, and `go install` builds the
one that matches the machine.

This is a small example as much as working code. It shows the two new
contributions, `languageServers` and `languageServerInstallers`, without a
download service, a bundled archive, or a second copy of Go.

## Install the plugin

Lumen ships no preinstalled plugins. Install this one like any other:

- **GUI**: `cd examples && zip -r lsp-gopls-plugin.zip lsp-gopls-plugin`,
  then Settings → Plugins → `+` → *From Zip Archive…*.
- **Folder** (development): copy the directory into the data directory as
  `plugins/lsp-gopls` — the folder name should match the manifest `id`:

  ```bash
  # Linux
  cp -r examples/lsp-gopls-plugin ~/.config/Lumen/plugins/lsp-gopls
  # macOS
  cp -r examples/lsp-gopls-plugin ~/Library/Application\ Support/Lumen/plugins/lsp-gopls
  ```

Then refresh the Plugins page. Installing the plugin is the consent for the
programs its manifest names (`go` and `gopls`), so there is nothing else to
turn on: the card's **Allow this plugin to start programs** switch is on, and
it exists to take that back later. With it switched off, the install command
fails with a clear error and the contributed server is not started.

## Install gopls

Open the language server panel (**Language Servers…**) and find the `go` row.
When gopls is not on `PATH`, the row is `未安装` and offers
**Install gopls with go install**, the installer declared by
`contributes.languageServerInstallers`. Select the row and press `I`; that
runs this plugin's own `lsp-gopls.install` command, with the permissions above.

The exact command is:

```sh
go install golang.org/x/tools/gopls@latest
```

It runs with the plugin's directory as the working directory, which has no
`go.mod`; the `@latest` form installs that module's main package at the
newest version, independent of any module the user happens to be in. `go`
writes its download and build progress to stderr; the command returns only
when the child exits. On failure the panel shows the error text (which this
plugin makes from the command's combined output); on success it refreshes the
row. Installer output is not streamed while the command runs.

`go install` does not change `PATH`. It puts the binary in:

```sh
$(go env GOBIN)                 # if GOBIN is set
$(go env GOPATH)/bin/gopls      # otherwise; GOPATH defaults to ~/go
```

Go's documented setup already puts `$(go env GOPATH)/bin` on `PATH`. This
plugin contributes a bare `gopls` name, so it relies on that: if the
directory is not on `PATH`, add it to your shell profile, or the core will
not see the server it just installed. A user who keeps servers elsewhere can
also point `LUMEN_LSP` at an absolute path.

## The contributions

```json
"languageServers": [
  { "langs": ["go"], "command": "gopls", "order": -1 }
],
"languageServerInstallers": [
  {
    "langs": ["go"],
    "command": "lsp-gopls.install",
    "label": "Install gopls with go install"
  }
]
```

- `langs` uses the editor's short language id, `go`.
- `command` is the binary for a server, and the id of a contributed command
  for an installer.
- `order: -1` puts this server ahead of the core's `PATH` discovery, which
  is order `0`; positive orders come after it. With the same `gopls` binary
  the ranking is bookkeeping, but it is what a plugin that really ships its
  own server uses to win over a discovered one.
- The installer's `label` is what the panel's not-installed row offers.

## Permissions, and why

| Permission | Why |
|---|---|
| `process: ["go"]` | The installer must start `go`. |
| `process: ["gopls"]` | The contributed server is `gopls`; a bare name, a relative path and an absolute path all have to be named here. The user also has to turn on the plugin's start-programs switch. |

No `network` permission is declared, and that is deliberate: Lumen's
`network` permission gates the plugin's own `fetch`, and this plugin never
fetches anything. The sockets belong to the `go` child, which is a normal
process following the user's `GOPROXY`, `GOFLAGS` and module cache — asking
for hosts here would put a promise in the install sheet that the plugin
does not keep.

The installer runs with the permissions the manifest declared and the user
turned on; it is not a sandboxed downloader. A plugin is code the user chose
to install, and this one runs only `go` and the contributed `gopls`.

No `workspaceRead` is needed: the plugin never reads project files, and the
language server is started by the core's LSP manager, not by `host.spawn`.

## Offline, and what failure looks like

`go install` is the only network step. Without a network it fails, unless the
module and its dependencies are already in the module cache; `go install`
can then finish from the cache.

- A failed install leaves any previous `gopls` in place; `go install` writes
  the new binary only after a successful build.
- The command throws an error carrying the tail of what `go` printed, so the
  panel shows the reason instead of a silent no-op.
- Nothing else changes: `PATH` discovery still runs, and the built-in Go
  definition parser still answers when there is no server. Lumen never
  downloads a server itself.

## Uninstall

1. Settings → Plugins: disable or uninstall **Go Language Server**. The server and
   installer contributions disappear; plugin data stays under
   `plugin-data/lsp-gopls/` so a reinstall keeps it.
2. The binary belongs to the Go toolchain, not to the plugin. Remove it if
   you no longer want it:

   ```sh
   bin=$(go env GOBIN)
   [ -n "$bin" ] || bin=$(go env GOPATH)/bin
   rm "$bin/gopls"
   ```

   On Windows the file is `gopls.exe`. The module cache under
   `$(go env GOMODCACHE)` is shared with every other Go build; leave it
   alone unless you mean to clear it.

## Why `go install`, not a release zip

1. **gopls needs the Go toolchain anyway.** It invokes `go` to load modules,
   build tags and type information. A standalone binary on a machine with no
   Go is not a working Go language server.
2. **There is no official standalone binary to pin.** Upstream distributes
   gopls through `go install`; a zip would have to be built and published by
   this plugin, with its own platform matrix, signing and update chain.
3. **The Go proxy and checksum database already sign the route.**
   `golang.org/x/tools/gopls` is fetched through the user's `GOPROXY` and
   verified against `sum.golang.org`. The plugin ships no executable and
   runs no downloader of its own.
4. **The build matches the machine.** `go install` compiles for the local
   platform and Go version instead of trusting an asset name.

The trade-off is that `@latest` tracks the newest release rather than a pin.
For a reproducible setup, change the command in `index.js` to a version, as
`golang.org/x/tools/gopls@v0.20.0`. A user whose Go is older than the newest
gopls requires gets `go`'s own error text, which says which version is
needed.

## What the JavaScript does

`index.js` exports `installGo`, plus `onCommand`, which routes the
contributed `lsp-gopls.install` command (the id the installer descriptor
names) to it. A small `run` helper does the process work:

1. `host.spawn("go", ["install", "golang.org/x/tools/gopls@latest"])`.
2. `await child.readLine()` until `null`, collecting stdout. This is
   `bufio.Scanner` on the host side, so it is line-buffered; a final line
   without `\n` is still delivered, and the stream ends at EOF.
3. `await child.wait()`, which answers the exit code.
4. `child.errorOutput()`, the buffered stderr — this is where `go install`
   writes its progress and its errors. It is read after the child exits, not
   streamed.
5. Answer `{ ok: true, output }`, or throw an `Error` whose message is the
   output. The host gives installer commands a ten-minute budget so a cold
   `go install`, which may compile gopls for a minute or two, fits in one
   call.

The documented `host.spawn` shape in `docs/PLUGINS.md` is brief; the
authoritative surface is `internal/pluginhost/host.go`: `pid`, `write`,
`closeStdin`, `kill`, `readLine`, `wait`, and `errorOutput` (not `stderr`).
`readLine`, `write` and `wait` return Promises.
