# Cursor Theme — Lumen 示例插件

这个插件把原先写在 `cmd/lumen/theme.go` 里的内置 **Cursor** 主题外置成了纯声明式的插件主题：`plugin.json` 的 `contributes.themes` 描述明暗两套颜色 token，宿主用 `themeTokens.go` 的 adapter 把它们还原成 `*palette`，再走既有的 `bringTheme()` 链路。因此它和 Lumen 自带主题一样出现在主题选择器、设置页的主题卡片和 View 菜单里；`accentedDialog` 为 false，对话框边框沿用普通边框色（与原来的 `ThemeProvider` 一致）。

## 安装

Lumen 不预装任何插件。两种安装方式：

- **文件夹（开发时用）**：把整个目录复制到数据目录的 `plugins/cursor-theme/`，目录名与 manifest 的 `id` 一致，然后刷新 Settings → Plugins（或重启 Lumen）。

  ```bash
  # Linux
  cp -r examples/cursor-theme-plugin ~/.config/Lumen/plugins/cursor-theme
  # macOS
  cp -r examples/cursor-theme-plugin ~/Library/Application\ Support/Lumen/plugins/cursor-theme
  ```

- **Zip**：`cd examples && zip -r cursor-theme-plugin.zip cursor-theme-plugin`，然后在 Settings → Plugins → `+` → *From Zip Archive…* 中选择它，刷新插件页后即可在主题选择器里看到 Cursor。

`index.js` 只是最小的 ESM 文件：安装时插件宿主会编译 `main`，但这个主题没有任何需要调用的代码。

## Token 是怎么生效的

- `dark` / `light` 各自有 `colors`、`syntax`、`ansi` 三部分。颜色值是 `#rrggbb`（不透明）或 `#rrggbbaa`（第 4 个字节是 0–255 的 alpha）；例如原代码里的 `ui.RGBA(240,240,240,0.067)` 在这里写成 `#f0f0f011`，`ui.RGBA(64,64,64,0.6)` 写成 `#40404099`。
- `mono` 是主题描述符顶层的布尔标记，**不在** `dark` / `light` 的 `colors` 里：设为 `true` 会让整窗使用代码字体、文件图标按调色板着色。Cursor 原本没有这个标记，本插件不声明它。
- **这是 partial overlay（局部覆盖）**：宿主先复制 `darkPalette()` / `lightPalette()`，只覆盖这里写出的字段，最后调用 `derive()` 重新推导由其他颜色生成的字段。没有列出的字段自动继承 Lumen 对应明暗调色板，不会变成零值（否则控件会画成黑色）。`syntax` 的名字必须是 `internal/highlight` 里的 kind 名（如 `Keyword`、`Type`、`Heading`），`ansi` 最多 16 个，按索引写入。
- **按钮的悬停 / 按下色跟着 `fill` 走**：只写 `colors.fill` 而不写 `fillHover` / `fillPressed` 时，宿主按明暗用 `fill` 的 `Mix` 补上这两色。本插件的 `fillHover` 是原 Cursor 调色板的手调值（不是 `Mix` 的结果），因此显式写出，宿主会原样保留。
- 未知字段名、非法颜色、未知 syntax kind 或超过 16 个 ANSI 都会在**激活时报错并写入日志**，并且不会注册任何东西（主题和它的命令都不会留下半套状态）。
- 宿主为 dark / light **各缓存一个 `*palette` 指针**。`paletteFade.step()` 用指针身份判断渐变是否要重启，所以每次 `Palette()` 都返回同一个指针；`p.dark` 也随窗口外观取对应的调色板，`applyTheme()` 据此设置窗口的 `Dark`。
- **停用插件后**主题和 `view.theme.*` 命令一起撤销，`paletteFor()` 回退到 Lumen 的 `darkPal` / `lightPal`，窗口渐变回到 Lumen 配色。旧设置值 `cursor` 不再对应内置主题；本插件的 ID 是 `cursor-theme.cursor`。

## 与内置主题的一致性

颜色数据（包括半透明色、语法高亮、终端 16 色和由 `Mix` 得到的 `fillPressed`）逐字段迁移；原主题没有 `mono` 标记，本插件也不声明它，由 `derive()` 重新推导的字段与原来的结果相同，装上后外观与原内置 Cursor 主题一致。

**Clawd 吉祥物与 Clauding spinner 不随之外置，已一并删除**（`clawd.go`、`clauding.go` 以及内置的 mascot 注册都已移除）。通用的 mascot 绘制机制仍保留，插件若需要可以自行通过 `mascots` 扩展点贡献角色；没有角色时欢迎页显示 Lumen logo，状态栏显示普通 spinner。
