// Cursor Theme is a purely declarative theme: every color is in
// plugin.json, under contributes.themes, and the host reads them from
// there. There is nothing for the host to call. Lumen still compiles
// main on install, so this file exports a harmless activation hook.
export function activate() {}
