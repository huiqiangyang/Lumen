# IntelliJ IDEA Keymap — Lumen 示例插件

这个插件把 IntelliJ IDEA 的两套**预定义键位**（macOS 与 Windows/Linux）贡献给 Lumen：
核心不再内置任何第三方键位预设，`contributes.keymapPresets` 里的一组 binding
就是全部键位。它同时演示纯声明式插件的最小形态：`plugin.json` 描述贡献，
`index.js` 只是能被加载的主模块，没有运行时逻辑。

键位表以 JetBrains 官方文档为准，逐条对齐：

- [Predefined macOS keymap](https://www.jetbrains.com/help/idea/reference-keymap-mac-default.html)
- [Predefined Windows keymap](https://www.jetbrains.com/help/idea/reference-keymap-win-default.html)（Windows 与 Linux 同一套）
- [Source code navigation](https://www.jetbrains.com/help/idea/navigating-through-the-source-code.html)、
  [Main version control shortcuts](https://www.jetbrains.com/help/idea/main-version-control-shortcuts.html)

## 安装

两种方式任选其一：

- **文件夹（开发用）**：把整个目录放进 Lumen 数据目录下的 `plugins/`，文件夹名与
  manifest 的 `id` 一致：

  ```bash
  # Linux
  cp -r examples/idea-keymap-plugin ~/.config/Lumen/plugins/idea-keymap
  # macOS
  cp -r examples/idea-keymap-plugin ~/Library/Application\ Support/Lumen/plugins/idea-keymap
  ```

- **Zip**：`cd examples && zip -r idea-keymap-plugin.zip idea-keymap-plugin`，然后在
  Settings → Plugins 里用 `+` → *From Zip Archive…* 安装。

装好后刷新 Plugins 页面（或重启 Lumen），在插件卡片上启用它。

## 启用之后

- Settings 的 **Keymap Preset** 里会出现 `idea-keymap.idea`（显示名 `IntelliJ IDEA`），
  选中即使用这套键位；`keybindings.json` 里的 `keymapPreset` 也写这个值。
- 一个预设同时容纳两套键位，平台专属键用 `isMac` / `!isMac` 条件按机器筛选：
  macOS 走 macOS 那一列，Windows/Linux 走 Windows/Linux 那一列；两列共用的键
  （`Alt+F7`、`F7`、`Alt+Shift+↑/↓` 等）不带平台条件，两边都生效。带
  `editorTextFocus` 的绑定只在编辑器里生效。`cmd/lumen/keynav_test.go` 用一张表
  逐条验证这个映射。
- 停用或卸载插件，这个选项与它的快捷键一起消失，窗口回到核心自带键位。
- 插件只贡献预设本身，不改写 `keybindings.json`；个人按键仍然覆盖预设。
- 预设绑定了与内置 Accel 相同的键时，`menuAccel` 会把内置快捷键让出来，预设键
  胜出（`cmd/lumen/commands.go`）。因此 `⌘B` / `Ctrl+B` 是「跳声明」而不是侧栏，
  `⌘[` / `⌘]` 是后退 / 前进而不是反缩进 / 缩进，`Ctrl+W` 是扩展选区而不是关闭 tab。
  注意 `Map.Binds` / `Map.Removes` **不评估 `when`**（`internal/keymap/keymap.go`），
  判断的是「有没有一条绑定以这个键开头」。所以另一平台的绑定、只带
  `editorTextFocus` 的绑定，也会把同键的内置 Accel 摘掉：非编辑器焦点下这类键
  可能既不跑内置命令、也不跑预设命令（详见「近义映射与偏差」）。

## 键位表

「macOS」列来自 macOS 预定义键位，「Windows/Linux」列来自 Windows 预定义键位。
Lumen 命令一列是承担这个动作的 Lumen 命令；标注 ≈ 的是近义映射，见下一节。

| IDEA 动作 | macOS | Windows/Linux | Lumen 命令 |
|---|---|---|---|
| Find Action... | `⌘⇧A` | `Ctrl+Shift+A` | `go.commands` |
| Settings... | `⌘,` | `Ctrl+Alt+S` | `file.settings` |
| Copy Paths | `⌘⇧C` | `Ctrl+Shift+C` | `file.copyPath` ≈ |
| Rename... | `⇧F6` | `Shift+F6` | `file.rename` ≈ |
| Save All | `⌘S` | `Ctrl+S` | `file.saveAll` |
| Go to Class | `⌘O` | `Ctrl+N` | `go.quickOpen` ≈ |
| Go to File... | `⌘⇧O` | `Ctrl+Shift+N` | `go.quickOpen` |
| Go to Symbol... | `⌘⌥O` | `Ctrl+Alt+Shift+N` | `go.symbol` ≈ |
| File Structure | `⌘F12` | `Ctrl+F12` | `go.symbol` |
| Find... | `⌘F` | `Ctrl+F` | `edit.find` |
| Replace... | `⌘R` | `Ctrl+R` | `edit.replace` |
| Find Next | `⌘G` | `F3` | `edit.findNext` |
| Find Previous | `⌘⇧G` | `Shift+F3` | `edit.findPrev` |
| Find in Files... | `⌘⇧F` | `Ctrl+Shift+F` | `edit.findInFiles` |
| Replace in Files... | `⌘⇧R` | `Ctrl+Shift+R` | `edit.replaceInFiles` |
| Recent Files | `⌘E` | `Ctrl+E` | `file.openRecent` |
| Go to Line/Column... | `⌘L` | `Ctrl+G` | `go.line` |
| Close Active Editor Tab | `⌘W` | `Ctrl+F4` | `file.close` |
| Show Diff / Compare Files | `⌘D` | `Ctrl+D` | `git.openChanges` ≈ |
| Duplicate Line or Selection | `⌘D` | `Ctrl+D` | `sel.copyDown` |
| Delete Line | `⌘⌫` | `Ctrl+Y` | `sel.deleteLine` |
| Move Line Up / Down | `⌥⇧↑` / `⌥⇧↓` | `Alt+Shift+Up` / `Alt+Shift+Down` | `sel.moveUp` / `sel.moveDown` |
| Comment with Line Comment | `⌘/` | `Ctrl+/` | `sel.comment` |
| Extend Selection | `⌥↑` | `Ctrl+W` | `sel.expand` |
| Shrink Selection | `⌥↓` | `Ctrl+Shift+W` | `sel.shrink` |
| Go to Declaration or Usages | `⌘B` | `Ctrl+B` | `go.definition` |
| Find Usages | `⌥F7` | `Alt+F7` | `go.usages` |
| Show Usages | `⌘⌥F7` | `Ctrl+Alt+F7` | `go.usages` ≈ |
| **Back** | **`⌘[`** | **`Ctrl+Alt+Left`** | `go.back` |
| **Forward** | **`⌘]`** | **`Ctrl+Alt+Right`** | `go.forward` |
| Last Edit Location | `⌘⇧⌫` | `Ctrl+Shift+Backspace` | `go.lastEdit` |
| Select Next Tab | `⌘⇧]` | `Alt+Right` | `go.nextTab` |
| Select Previous Tab | `⌘⇧[` | `Alt+Left` | `go.prevTab` |
| Show Project window | `⌘1` | `Alt+1` | `view.sidebar` |
| Show Bookmarks window | `⌘2` | `Alt+2` | `view.agentSwitcher` ≈ |
| Show Find window | `⌘3` | `Alt+3` | `view.search` ≈ |
| Show Terminal window | `⌥F12` | `Alt+F12` | `view.terminal` |
| Show Version Control window | `⌘9` | `Alt+9` | `view.scm` ≈ |
| Show Commit window | `⌘0` | `Alt+0` | `git.openCommit` |
| VCS Operations Popup... | `⌃V` | `Alt+\`` | `git.switchBranch` ≈ |
| Commit... | `⌘K` | `Ctrl+K` | `git.openCommit` |
| Update Project | `⌘T` | `Ctrl+T` | `git.pull` ≈ |
| Rollback | `⌘⌥Z` | `Ctrl+Alt+Z` | `git.rollback` |
| Push... | `⌘⇧K` | `Ctrl+Shift+K` | `git.push` |
| Next / Previous Change | `⌃⌥⇧↓` / `⌃⌥⇧↑` | `Ctrl+Alt+Shift+Down` / `Up` | `git.nextChange` / `git.prevChange` |
| Next / Previous Difference | `F7` / `⇧F7` | `F7` / `Shift+F7` | `git.nextChange` / `git.prevChange` ≈ |

`Ctrl+[` / `Ctrl+]` 在 Windows 预定义键位里是「移到代码块首 / 尾」，Lumen 没有对应
命令；插件用两条 `-sel.outdent` / `-sel.indent` removal 把 Lumen 内置的反缩进 /
缩进从这两个键上摘掉，避免 IDEA 的键在 Windows 上做错事。

## 近义映射与偏差

Lumen 不是 IDEA，以下动作只能由最接近的命令承担：

- **搜索类**：`go.quickOpen` 同时承担 Go to Class 与 Go to File；`go.symbol` 是文件内
  符号列表（`openQuick("@")`），同时承担 Go to Symbol 与 File Structure。
- **用法类**：Find Usages 与 Show Usages 都是 `go.usages`（Lumen 只有一个用法浮层）。
- **VCS 类**：Update Project → `git.pull`；VCS Operations Popup →
  `git.switchBranch`（分支选择器）；Show Diff / Compare Files → `git.openChanges`；
  Show Version Control window → `view.scm`；Show Commit window 与 Commit... →
  `git.openCommit`（只打开提交窗，不直接提交）。`⌘D` / `Ctrl+D` 按上下文分层：编辑器里
  是「复制行」，其它焦点是「查看改动」，对应 IDEA 里编辑区与 Diff Viewer 的区别。
- **文件动作**：Copy Paths → `file.copyPath`（复制活动文件路径，不是相对路径 /
  引用）；Rename... → `file.rename`（重命名活动文件，不是符号级重构）。
- **工具窗**：IDEA 的 `⌘2` / `Alt+2` 是 Bookmarks，Lumen 没有书签，这一格给了
  浮动会话切换器；`⌘3` / `Alt+3` 是 Find 工具窗，给了搜索面板。Run / Debug /
  Services / Problems 等工具窗（4–8）Lumen 没有对应面板，未绑定。
- **没有对应命令、因此未绑定**：调试器、符号级重构（Shift+F6 已按文件重命名
  近似绑定）、书签工具窗、代码补全 / 意图动作 / 格式化、折叠、多光标、
  Search Everywhere（双击 Shift）、Go to Implementation / Test、
  Previous/Next Method、代码块的插入符移动等。剪贴板、撤销重做、Tab / Shift+Tab
  缩进等由编辑器和系统菜单原生处理，与 IDEA 一致，不需要绑定。
- **内置键位会被摘掉**：预设是「覆盖」而不是「替换整套键位」，但 `Binds` /
  `Removes` 不看 `when`，所以同键的内置 Accel 在本机也被摘掉，即使那条绑定属于
  另一个平台或只在编辑器里生效。结果：macOS 的 `Alt+←/→`（Back/Forward）、
  `Ctrl+G`（Go to Line）、`⌘0`（缩放重置）、`⇧⌘]/[`（切项目）等让位；
  Windows 的 `Ctrl+W` 让位给扩展选区。多数由同命令的 IDEA 键接管（如 `⌘L`、
  `⌘[`），少数变成空键。带 `editorTextFocus` 的键（如 `⌘/`）在非编辑器焦点下
  也既不跑内置也不跑预设命令。这是现有 keymap 机制的边界，要给 `Binds` 传上下文
  才能彻底消除；`cmd/lumen/keynav_test.go:TestIDEAKeymapOverridesBuiltinAccelerators`
  锁住了「让位」本身。
- **终端焦点**：`panel.go` 先试 `keyStroke`，所以任何 `when` 成立的预设键（包括
  `F7` / `⇧F7`、`⌥F12`、`Ctrl+Alt+Shift+↑/↓`、Back/Forward、`⌘/Alt+1/2/3/9/0`）
  都会抢在 shell 前面，无论是否带焦点条件。这是原有行为，不是 IDEA 的终端行为。
- **Lumen 自有键**：IDEA 里没有的动作（分栏、缩放、`view.newTerminal` 等）保留
  Lumen 自带键；Windows 上 `Ctrl+H`（`edit.replace` 的 `otherAccels`）也仍是
  打开替换，与 `Ctrl+R` 并存。

## Back / Forward 的行为

`⌘[` / `⌘]`（`Ctrl+Alt+Left` / `Right`）走 `go.back` / `go.forward`。核心的导航历史
记录两类位置：跳定义 / 用法浮层的出发点，以及**在新位置开始编辑时离开的那个位置**
（`cmd/lumen/usages.go: recordEditPlace` → `navPush`）。连续键入会合并成一条，`⌘⇧⌫`
的「上次编辑位置」仍是独立栈（`go.lastEdit`）。与 IDEA 尚有的差别：单纯点击移动光标
而不编辑、不跳转，目前不会写入历史。测试见 `cmd/lumen/navhistory_test.go`。

## 文件

| 文件 | 作用 |
|---|---|
| `plugin.json` | manifest，`contributes.keymapPresets` 里是 91 条绑定（89 条键位 + 2 条 removal） |
| `index.js` | 主模块，只有一个空的 `activate`，说明这是声明式插件 |
| `locales/` | 预设显示名的翻译 |

## 说明

- 没有 `permissions`：预设只描述快捷键，不读写文件、不联网、不启动进程。
- `cmd/k` / `Ctrl+K` 打开 Commit 工具窗口（`git.openCommit`），编辑器内的绑定带
  `when` 条件；平台专属键带 `isMac` / `!isMac`。
- 旧数据里的 `shift+shift`（双击 Shift）没有迁移：修饰键不能单独作为一个按键，
  `keymap.ParseKeys` 解析不了它；宿主对声明了非法 key 的预设会明确报错并跳过那一条。
- 想加别的键位方案，复制这个目录、改 `id`、`name` 和 `keymapPresets[0].id` 即可。
