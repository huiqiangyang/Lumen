// IntelliJ IDEA Keymap is a declarative plugin: its shortcuts are all in
// plugin.json, under contributes.keymapPresets, so the host installs and
// lists the preset without calling into this file. It is here because a
// plugin needs a main module to load, and so that a later version has a
// place to grow behaviour (a command of its own, a setting, a migration).
export function activate() {}
