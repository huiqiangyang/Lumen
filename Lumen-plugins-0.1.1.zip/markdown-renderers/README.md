# Markdown Renderers — Lumen 示例插件

This is **the only math and Mermaid renderer Lumen ships**: the built-in
MathJax / Pele copies and their moejs runtime have been removed from the
binary. The app preinstalls no plugins, so `math` blocks and `$…$` / `$$…$$`
in a Markdown preview, `mermaid` blocks and `.mmd` previews show an "install
a renderer plugin" note until this plugin is installed. One plugin now
contributes both renderers; the former `examples/mathjax-plugin/` and
`examples/mermaid-plugin/` are gone.

## Install

The app ships with no preinstalled plugins. Either

- **Folder** (development): copy this directory to the data directory as
  `plugins/markdown-renderers` (the folder name should match the manifest
  `id`; the `-plugin` suffix belongs to the repository directory only):

  ```bash
  # Linux
  cp -r examples/markdown-renderers-plugin ~/.config/Lumen/plugins/markdown-renderers
  # macOS
  cp -r examples/markdown-renderers-plugin ~/Library/Application\ Support/Lumen/plugins/markdown-renderers
  ```

- **Zip**: `cd examples && zip -r markdown-renderers.zip markdown-renderers-plugin`,
  then Settings → Plugins → `+` → *From Zip Archive…*.

Then refresh the Plugins page (or restart Lumen). If you installed the two old
example plugins, remove `plugins/mathjax-plugin` and `plugins/mermaid-plugin`
first: two plugins with `order: -1` on the same language would compete for the
same fence block. Disabling or uninstalling this plugin leaves no built-in
fallback: the preview shows the install note again for both languages.

## What it does

`plugin.json` contributes two `markdownBlockRenderers` entries:

| language | export | bundle | host side |
|---|---|---|---|
| `math` | `renderMath` | MathJax 3.2.2 → SVG (`LumenMath`) | `mathFormulaFromSVG` reads the viewBox, computes width / ascent / depth, draws the glyph paths and handles exports |
| `mermaid` | `renderMermaid` | Pele 1.9.0 → SVG (`Pele`) | `mermaidDiagramFromSVG` resolves `var(--pele-…)` against the theme, extracts label text and tiles large diagrams (`mermaidTiles`) |

The host sends `{ text, display }` for math and `{ text }` for Mermaid and
expects `{ svg }` (or `{ error }`); it owns everything after that. Each
contribution's `order: -1` puts it ahead of other plugin renderers for its
language; the host contributes no renderer of its own. Both bundles live in
one `index.js` and therefore share one plugin VM. No `permissions` are needed:
the plugin reads no project files, uses no network and starts no processes.

## Updating `index.js`

`index.js` in this directory is the **only copy** of the two upstream bundles.
`cmd/lumen/assets/` no longer holds a `.js.gz` to rebuild from. The file is
laid out as follows:

1. the MathJax license comment (Apache-2.0) and its bundle, a self-contained
   IIFE assigned to `var LumenMath`;
2. the Pele license comment (MIT + the Lucide ISC notice) and its bundle, a
   self-contained IIFE assigned to `var Pele`;
3. two thin export wrappers.

The `var`s are module-scoped, not `window` globals; the wrappers see them
because they are in the same ES module. To update one renderer, replace just
that bundle part (license comment included) with the new upstream bundle and
keep the wrappers. The wrappers are:

```js
export function renderMath(req) {
  try {
    const svg = LumenMath.render(req.text, req.display);
    return { svg: svg };
  } catch (err) {
    return { error: String(err) };
  }
}

export function renderMermaid(req) {
  try {
    const res = Pele.render(req.text);
    return { svg: res.svg };
  } catch (err) {
    return { error: String(err) };
  }
}
```

Upstream sources: <https://github.com/mathjax/MathJax-src> (3.2.2,
Apache-2.0) and <https://github.com/obsidianmd/pele> (1.9.0, MIT). Do not
strip either license comment when replacing a bundle.

## Runtime and host limits

- The plugin runs in a normal plugin VM: **256 MiB** per VM and a **30s**
  `Call` timeout, shared by both renderers. There is no per-formula or
  per-diagram interrupt; a pathological block waits for the host call
  timeout, which only affects that one block.
- Cold start compiles the ~2.4 MiB of bundle once (about 58 ms for MathJax
  and 71 ms for Pele in the 2026-11-07 feasibility check); warm calls were
  about 1.1 ms for a formula and 0.38 ms for a diagram.
- **No font measurement injection**: the removed built-in wrapper installed a
  `lumenMeasure` callback so Pele measured labels with the window's real
  fonts. A plugin VM has no such callback, so Pele falls back to its own
  character-width table. Layout stays valid, but tight label alignment can
  differ; there is no `host.measureText` API yet.
- The host caps a returned SVG at 4 MiB in `markdownRenderSVG` and 8 MiB in
  `mermaidDiagramFromSVG`, validates the math viewBox and the diagram's
  width/height, and limits tile count; malformed or oversized output shows an
  error instead of hanging a frame.

See `docs/PLUGINS.md` §4.2 and `docs/USING-PLUGINS.md` §6 / §9 for the
`markdownBlockRenderers` contract and the plugin lifecycle.
